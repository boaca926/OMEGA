#include "Getname.C"
#include <iostream>
#include <string>

using namespace std;

void getree() 
{
	
	Int_t mctype = 0;
	Double_t threepiIM = 0.;
	Double_t isrE = 0.;
	Double_t chi2value = 0.;
	// tree names
	TString OMEGAPI = gettreename(0); //
	TString KPM = gettreename(1); //
	TString KSL = gettreename(2); //
	TString THREEPIGAM = gettreename(3); //
	TString THREEPI = gettreename(4); //
	TString ETAGAM = gettreename(5); //
	TString BKGSUM1 = gettreename(6); //
	TString BKGSUM2 = gettreename(7); //
	TString MCSUM = gettreename(8);
	TString ALLCHAIN = gettreename(9); //
	// branche names
	TString Smctype = getbraname(0);
	TString SIMthreepi = getbraname(1); //std::cout<<getbraname(1)<<endl;
	TString SEisr = getbraname(2); //std::cout<<getbraname(2)<<endl;
	TString Schi2value = getbraname(3);
	
	TTree *TOMEGAPI_MC = new TTree("T"+OMEGAPI+"_MC","recreate");
	TTree *TKPM_MC = new TTree("T"+KPM+"_MC","recreate");
	TTree *TKSL_MC = new TTree("T"+KSL+"_MC","recreate");
	TTree *TTHREEPI_MC = new TTree("T"+THREEPI+"_MC","recreate");	
	TTree *TTHREEPIGAM_MC = new TTree("T"+THREEPIGAM+"_MC","recreate");
	TTree *TETAGAM_MC = new TTree("T"+ETAGAM+"_MC","recreate");
	TTree *TBKGSUM1_MC = new TTree("T"+BKGSUM1+"_MC","recreate");
	TTree *TBKGSUM2_MC = new TTree("T"+BKGSUM2+"_MC","recreate");
	TTree *TMCSUM_MC = new TTree("T"+MCSUM+"_MC","recreate");
	
	TTree *TTHREEPIGAM_Pre = new TTree("T"+THREEPIGAM+"_Pre","recreate");
	
	// add trees into TList
	TCollection* treelist = new TList;
	treelist->Add(TOMEGAPI_MC); 
	treelist->Add(TKPM_MC);	
	treelist->Add(TKSL_MC);	
	treelist->Add(TTHREEPI_MC);
	treelist->Add(TTHREEPIGAM_MC);
	treelist->Add(TETAGAM_MC);
	treelist->Add(TBKGSUM1_MC);
	treelist->Add(TBKGSUM2_MC); 
	treelist->Add(TMCSUM_MC);
	
	treelist->Add(TTHREEPIGAM_Pre);
	// scan the list and add branches	
	TObject* treeout=0;
	TIter treeliter(treelist);
	while((treeout=treeliter.Next()) !=0) {
		//treeout->Print();
		TTree* tree_temp=dynamic_cast<TTree*>(treeout);
		tree_temp->Branch(SIMthreepi+"_MC",&threepiIM,SIMthreepi+"/D");
		tree_temp->Branch(SEisr+"_MC",&isrE,SEisr+"/D");
		tree_temp->Branch(Schi2value,&chi2value,Schi2value+"/D");
	}
	
	// define chain
	TChain *allchainrho_mc = new TChain(ALLCHAIN+"_MC");
	TChain *allchainksl_mc = new TChain(ALLCHAIN+"_MC");
	
	TChain *allchainrho_pre = new TChain(ALLCHAIN+"_Pre");

	// create chain list
	TCollection* chainlist = new TList; 
	chainlist->Add(allchainrho_mc);
	chainlist->Add(allchainksl_mc);
	
	chainlist->Add(allchainrho_pre);

	// mcrho samples, threepi-isr hadronic events
	string line;
   ifstream filelist("./mcrhoutpath");
   ifstream filelist1("./mcksloutpath");
   //  ifstream filelist("filelist.txt");
   if (filelist.is_open()) {
      while (!filelist.eof()) {
         if (getline(filelist, line, '\n')){
            if (line[0] != '!') {          	
               allchainrho_mc->Add(line.data()); 
               allchainrho_pre->Add(line.data());                            
               cout << "Adding file: " << line << " to the chain of files" << endl;       
               // scan the list and add branches	
					TObject* chainout=0;
					TIter chainliter(chainlist);
					while((chainout=chainliter.Next()) !=0) {
						//chainout->Print();
						TTree* chain_temp=dynamic_cast<TTree*>(chainout);
						chain_temp->SetBranchAddress(SIMthreepi,&threepiIM);
						chain_temp->SetBranchAddress(SEisr,&isrE);
						chain_temp->SetBranchAddress(Smctype,&mctype);
						chain_temp->SetBranchAddress(Schi2value,&chi2value);
					}	
               
            }
         }
      }
      filelist.close();
   } else {
      cout << "Unable to open filelist" << endl;
      return 0;
   }
   //
   if (filelist1.is_open()) {
      while (!filelist1.eof()) {
         if (getline(filelist1, line, '\n')){
            if (line[0] != '!') {          	
               allchainksl_mc->Add(line.data());                            
               cout << "Adding file: " << line << " to the chain of files" << endl;       
               // scan the list and add branches	
					TObject* chainout=0;
					TIter chainliter(chainlist);
					while((chainout=chainliter.Next()) !=0) {
						//chainout->Print();
						TTree* chain_temp=dynamic_cast<TTree*>(chainout);
						chain_temp->SetBranchAddress(SIMthreepi,&threepiIM);
						chain_temp->SetBranchAddress(SEisr,&isrE);
						chain_temp->SetBranchAddress(Smctype,&mctype);
					}	
               
            }
         }
      }
      filelist1.close();
   } else {
      cout << "Unable to open filelist1" << endl;
      return 0;
   }

	/// fill trees
	/// generated MC events ///
	// signal
   Int_t mcsumNb_MC=0;
   Int_t omegamNb_MC=0;
   for (Int_t irow=0;irow<allchainrho_mc->GetEntries();irow++) {
   	allchainrho_mc->GetEntry(irow); 
   	if (mctype == 4) {
   		omegamNb_MC++; mcsumNb_MC++;
   		TTHREEPIGAM_MC->Fill();
   		TMCSUM_MC->Fill();
   	}	

   }
   // all physics
   Int_t omegapiNb_MC=0, kpmNb_MC=0, kslNb_MC=0, threepiNb_MC=0, etagamNb_MC=0, bkgsum1Nb_MC=0;
   for (Int_t irow=0;irow<allchainksl_mc->GetEntries();irow++) {
   	allchainksl_mc->GetEntry(irow); 
   	if (mctype == 1) {
   		omegapiNb_MC++; mcsumNb_MC++;
   		TOMEGAPI_MC->Fill();
   		TMCSUM_MC->Fill();
   	}	
   	else if (mctype == 2) {
   		kpmNb_MC++; mcsumNb_MC++;
   		TKPM_MC->Fill();
   		TMCSUM_MC->Fill();
   	}
   	else if (mctype == 3) {
   		kslNb_MC++; mcsumNb_MC++;
   		TKSL_MC->Fill();
   		TMCSUM_MC->Fill();
   	}
   	else if (mctype == 5) {
   		threepiNb_MC++; mcsumNb_MC++;
   		TTHREEPI_MC->Fill();
   		TMCSUM_MC->Fill();
   	}
		else if (mctype == 7) {
			etagamNb_MC++; mcsumNb_MC++;
			TETAGAM_MC->Fill();
			TMCSUM_MC->Fill();
		}
		else if (mctype==6 || mctype==8 || mctype==9) {
			bkgsum1Nb_MC++; mcsumNb_MC++;
			TBKGSUM1_MC->Fill();
			TMCSUM_MC->Fill();
		}
   }
   // eeg
   
   // data
   
   /// pre-selected MC events (with all cuts) ///
   // signal
   Int_t mcsumNb_Pre=0;
   Int_t omegamNb_Pre=0;
   for (Int_t irow=0;irow<allchainrho_pre->GetEntries();irow++) {
   	allchainrho_pre->GetEntry(irow); 
   	if (mctype == 4) {
   		omegamNb_Pre++; mcsumNb_Pre++;
   		TTHREEPIGAM_Pre->Fill();
   		//TMCSUM_Pre->Fill();
   	}	

   }
   // allphysics
   
   // eeg
   
   /// pre-selected Reconstr. events ///
   // signal
   
   // allphysics
   
   // eeg
   
   // data

	printf("=================Generated=================\n");
   printf("# OMEGAPI_MC = %d \n", omegapiNb_MC);
   printf("# KPM_MC = %d \n", kpmNb_MC);
   printf("# KSL_MC = %d \n", kslNb_MC);
   printf("# ThreePiGam_MC = %d \n", omegamNb_MC);  
   printf("# ThreePi_MC = %d \n", threepiNb_MC); 
   printf("# ETAGam_MC = %d \n", etagamNb_MC);
   printf("# BKGSUM1_MC = %d \n", bkgsum1Nb_MC);
   //printf("# BKGSUM2_MC = %d \n", bkgsum2Nb_MC);
   printf("============================================\n");
   printf("# MCSUM_MC = %d \n", mcsumNb_MC);
   printf("=================Pre-selected=================\n");
   //printf("# OMEGAPI_MC = %d \n", omegapiNb_MC);
   //printf("# KPM_MC = %d \n", kpmNb_MC);
   //printf("# KSL_MC = %d \n", kslNb_MC);
   printf("# ThreePiGam_Pre = %d \n", omegamNb_Pre);  
   //printf("# ThreePi_MC = %d \n", threepiNb_MC); 
   //printf("# ETAGam_MC = %d \n", etagamNb_MC);
   //printf("# BKGSUM1_MC = %d \n", bkgsum1Nb_MC);
   //printf("# BKGSUM2_MC = %d \n", bkgsum2Nb_MC);
   printf("============================================\n");
   //printf("# MCSUM_MC = %d \n", mcsumNb_MC);
   
   
   TFile ftree("./TREE_Gen.root","recreate");
	TTHREEPIGAM_MC->Write();
	TOMEGAPI_MC->Write();
	TKSL_MC->Write();
	TTHREEPI_MC->Write();
	TETAGAM_MC->Write();
	TBKGSUM1_MC->Write();
	TMCSUM_MC->Write();

	TFile ftree("./TREE.root","recreate");
	TTHREEPIGAM_Pre->Write();



























}
